package com.singlepointsol.userloginsignupsqlitedatabase

data class User( val name: String, val email: String, val password: String, val mobile: String)
